# homelab-panel
This is a web-panel written in plain HTML /CSS to quickly access all 
of your selfhosted webapps or favorite sites

## Use this for yourself

To use this for yourself, you can clone this repository and put the files on 
a webserver like Apache2 or Nginx.

The logo of your apps need to be 64x64 px. You can just edit the file's names, button texts and URLs 
in the HTML files to add your own logos / links.

There is space for 12 logos / links in each category.